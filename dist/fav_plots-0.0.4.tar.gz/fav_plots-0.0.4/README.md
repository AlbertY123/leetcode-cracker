I love data visualization that helps everyone to make sense of data and see the beauty in it. 

This package will include my favoriate dataviz and makes it easy to produce them. 

## Installation

You can install this package by running

`pip install fav_plots`

## Unit test

* Create a virtual environment
* Install unit requirements for local development and the project package in a developer mode:
    * `pip install -r unit-requirements.txt`
    * `pip install -e .`
* Run unit test
    * `pytest tests/unit --cov` 
