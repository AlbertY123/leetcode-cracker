I love data visualization that helps everyone to make sense of data and see the beauty in it. 

This package will include my favoriate dataviz and makes it easy to produce them. 

## Installation

You can install this package by running

`pip install fav_plots`

## Usage

Here's how to use this package:

```python
import fav_plots

```
